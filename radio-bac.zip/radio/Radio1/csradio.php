<?php
ob_start();
header('Location: http://bymisi.dyndns.org/radio/player.php?url=http://195.70.35.172:8000/radio1.mp3');
?>