<?php
ob_start();
header('Location: http://bymisi.selfip.com/radio/player.php?url=http://66.103.27.16:13110');
?>