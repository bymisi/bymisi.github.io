<?php
ob_start();
header('Location: http://bymisi.selfip.com/radio/player.php?url=http://89.238.252.146:7000');
?>