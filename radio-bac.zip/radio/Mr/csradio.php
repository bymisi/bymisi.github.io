<?php
ob_start();
header('Location: http://bymisi.selfip.com/radio/player.php?url=http://bymisi.selfip.com:8600/mp3');
?>