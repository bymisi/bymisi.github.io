<?php
ob_start();
header('Location: http://bymisi.selfip.com/radio/player.php?url=http://scfire-mtc-aa06.stream.aol.com:80/stream/1074');
?>