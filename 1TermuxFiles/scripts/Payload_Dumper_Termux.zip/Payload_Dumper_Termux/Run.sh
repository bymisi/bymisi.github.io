python payload_dumper.py payload.bin
