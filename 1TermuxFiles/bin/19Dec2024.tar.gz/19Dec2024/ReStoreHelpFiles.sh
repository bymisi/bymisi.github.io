mv 18Dec2024-HelpFile ~/help
mv 18Dec2024-Vernyomas.test ~/Vernyomas.test
sleep 1;


mv -t ~/../usr/bin ReKompile-HostFile Adhost SizeAll BlockAds SizeDir EnableAds SizeFile GiTbyMiSipushGit UpdateHelpFile Help Vernyomas KeyGen XMXDC Mine ReStoreHelpFiles.sh
