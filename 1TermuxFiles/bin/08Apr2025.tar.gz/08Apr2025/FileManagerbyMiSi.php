 killall php
cat ~/../usr/bin/fileManagerbyMiSi.php > fileManagerbyMiSi.php
php -S 127.0.0.1:9876 &
xdg-open http://127.0.0.1:9876/fileManagerbyMiSi.php
wait
