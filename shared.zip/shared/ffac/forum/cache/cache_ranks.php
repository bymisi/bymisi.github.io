<?php

define('PUN_RANKS_LOADED', 1);

$pun_ranks = array (
  0 => 
  array (
    'id' => '6',
    'rank' => 'No SteamID',
    'min_posts' => '0',
  ),
  1 => 
  array (
    'id' => '5',
    'rank' => 'Noob',
    'min_posts' => '50',
  ),
  2 => 
  array (
    'id' => '4',
    'rank' => 'Low-',
    'min_posts' => '25000',
  ),
  3 => 
  array (
    'id' => '3',
    'rank' => 'Low+',
    'min_posts' => '40000',
  ),
  4 => 
  array (
    'id' => '1',
    'rank' => 'New player',
    'min_posts' => '49999',
  ),
  5 => 
  array (
    'id' => '2',
    'rank' => 'Player',
    'min_posts' => '50001',
  ),
  6 => 
  array (
    'id' => '7',
    'rank' => 'High-',
    'min_posts' => '60000',
  ),
  7 => 
  array (
    'id' => '8',
    'rank' => 'High+',
    'min_posts' => '75000',
  ),
);

?>