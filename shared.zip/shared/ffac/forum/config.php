<?php


//punbb database
$db_type = 'mysql';
$db_host = 'localhost';
$db_name = 'punbb'; //don't change taht !
$db_username = 'username';
$db_password = 'password';
$db_prefix = '';
$p_connect = false;

$cookie_name = 'punbb_cookie';
$cookie_domain = '';
$cookie_path = '/';
$cookie_secure = 0;
$cookie_seed = 'ce6f898b';

//FFAC stats database
$db_ffac_type = 'mysql';
$db_ffac_host = 'localhost';
$db_ffac_name = 'ffachmp'; //don't change taht !
$db_ffac_username = 'username';
$db_ffac_password = 'password';

//FFAC site URL
$full_site_url = 'http://82.232.102.55/FFAC';

//Googlemap config
$ggmapkey="ABQIAAAAxu80M2EWU1TltObBPBmH4BQRjQLBOvvmbFq3CzmfEVLxxkDKThR7H5Mz3rEp0MdrQhdZRQAq9ohsyQ"; //put your google key here

define('PUN', 1);
