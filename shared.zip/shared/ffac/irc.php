	<applet code=IRCApplet.class archive="IRC/irc.jar,IRC/pixx.jar" width=640 height=480>
	<param name="CABINETS" value="IRC/irc.cab,IRC/securedirc.cab,IRC/pixx.cab">
	<param name="nick" value="FFACUser???">
	<param name="userid" value="myname">
	<param name="name" value="ffacpjirc@ffac.org">
	<param name="host" value="irc.quakenet.org">
	<param name="command1" value="/join #ufb">
	<param name="gui" value="pixx">
	</applet>