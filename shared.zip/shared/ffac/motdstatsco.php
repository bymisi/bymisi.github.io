<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>FFAC : Free For All CS Championship</title>
</head>
<body bgcolor='#4A4A4A'>

<?php




echo "<h3><span>Server connections stats (".$_GET["id"].")</span></h3>";
echo "<h3><span>FFAC : http://82.232.102.55/FFAC</span></h3>";
$id=$_GET["id"];
echo '<img src="cgraph.php?id='.$id.'" >';
echo '<br>';
echo '<img src="cgrapm.php?id='.$id.'" >';


?>
</body>
</html>