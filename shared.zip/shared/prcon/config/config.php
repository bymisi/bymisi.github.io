<?php

  //User name
  $config_user_name = "rcon";

  //User password
  $config_user_password = "rcon";

  //relative path to the selected theme, from PHPrcon root dir
  $config_theme = "basic";

  //1 = a small helptext will be displayed on top of every page; 0 = no helptext
  $config_helptext = 1;

  //language of PHPrcon
  $config_language = "english";
  
  //IP of the Gameserver may be IP or Domain Name
  $config_server_ip = "your.server.net";

  //Port of the Gameserver
  $config_server_port = "27015";

  //rcon password of the Gameserver
  $config_server_password = "yourpassword";
  
  //Number of pages of maps that are sent from the server
  $config_map_amount = 1;

  //1 = PHPrcon is running on the same server as your Gameserver, 0 = PHPrcon is running anywhere
  $config_localserver = 0;

  //List of Config Files
  //absolute path to the xxxx.cfg that should be editable in PHPrcon (if $config_localserver = 0 this has no effect at all)
  //no config files specified
?>