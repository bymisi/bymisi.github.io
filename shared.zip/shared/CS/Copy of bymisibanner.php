<html>
<body topmargin="0" leftmargin="0" marginwight="0" marginheight="0" style="margin: 0px bgcolor="000000">
<a href="http://dl.dropbox.com/u/60645642/cstrike/gfx/bymisibanner.gif" target="_new">
<img src="http://dl.dropbox.com/u/60645642/cstrike/gfx/bymisibanner.gif"></a>
</body>
</html>