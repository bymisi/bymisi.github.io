<html>
<body topmargin="0" leftmargin="0" marginwight="0" marginheight="0" style="margin: 0px bgcolor="000000">
<img src="http://dl.dropbox.com/u/60645642/cstrike/gfx/banner.gif"></a>
</body>
</html>