<HTML>
     <HEAD>
<meta HTTP-EQUIV="REFRESH" content="0; url=http://bymisi.dyndns.org/shared/cs/2bymisibanner.php">
     </HEAD>
</HTML>