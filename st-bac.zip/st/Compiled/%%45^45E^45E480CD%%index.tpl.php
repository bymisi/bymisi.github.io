<?php /* Smarty version 2.6.26, created on 2011-10-31 12:43:05
         compiled from index.tpl */ ?>
<?php echo $this->_tpl_vars['html']; ?>