<?php
echo <<<EOL


  </body>
</html>
EOL;
?>