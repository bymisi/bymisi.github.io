<?php
ob_start();
header('Location: http://bymisi.dyndns.org/radio/player.php?url=http://www.savetofile.net:7000/');
?>