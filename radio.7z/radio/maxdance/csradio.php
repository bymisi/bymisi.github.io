<?php
ob_start();
header('Location: http://bymisi.dyndns.org/radio/player.php?url=http://cp.internet-radio.org.uk:15114/');
?>