<?php
ob_start();
header('Location: http://bymisi.selfip.com/radio/player.php?url=http://78.159.104.136:80');
?>