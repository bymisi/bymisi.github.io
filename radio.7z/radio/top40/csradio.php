<?php
ob_start();
header('Location: http://bymisi.selfip.com/radio/player.php?url=http://cp2.internet-radio.org.uk:30454/');
?>