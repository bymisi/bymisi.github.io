<?php
ob_start();
header('Location: http://bymisi.selfip.com/radio/player.php?url=http://95.169.188.110:8000/');
?>