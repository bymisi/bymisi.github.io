<?php
ob_start();
header('Location: http://bymisi.selfip.com/radio/player.php?url=http://95.154.216.44:8054');
?>