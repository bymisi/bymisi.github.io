<?php
ob_start();
header('Location: http://bymisi.dyndns.org/radio/player.php?url=http://83.169.60.44:80');
?>