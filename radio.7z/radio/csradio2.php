<?php
ob_start();
header('Location: http://bymisi.selfip.com/radio/player.php?url=http://listen.technobase.fm/tunein-dsl-pls');
?>